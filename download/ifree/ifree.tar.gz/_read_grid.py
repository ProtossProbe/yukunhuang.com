import numpy as np

def wrapOmega(gr):
    gr = gr % 360
    if gr >= 0 and gr <= 90:
        return gr
    elif gr > 90 and gr <= 180:
        return 180 - gr
    elif gr > 180 and gr <= 270:
        return gr - 180
    elif gr > 270 and gr <= 360:
        return 360 - gr

def I_Omega_trans(q, p):
    q, p = np.deg2rad(q), np.deg2rad(p)
    I = np.sqrt(q**2 + p**2)
    Omega = np.arctan2(p, q)
    return np.rad2deg(I), np.rad2deg(Omega)

def q_p_trans(I, Omega):
    I, Omega = np.deg2rad(I), np.deg2rad(Omega)
    q = I*np.cos(Omega)
    p = I*np.sin(Omega)
    return np.rad2deg(q), np.rad2deg(p)

FILENAME = 'qp_forced_grid.txt'

anum = 84
enum = 26
incnum = 21
gnum = 10
num = anum * enum * incnum * gnum

amin = 39.4
amax = 47.7
alist = np.linspace(amin, amax, anum)

emax = 0.25
elist = np.linspace(0, emax, enum)
elist[0] = 0.001

incmax = 40
inclist = np.linspace(0, incmax, incnum)
inclist[0] = 0.02

glist = np.linspace(0, 90, gnum)

def readGrid(filename):
    q, p = [], []
    file = open(filename, 'r')
    lines = file.readlines()
    counter = 0
    for line in lines:
        q.append(float(line.split(' ')[0]))
        p.append(float(line.split(' ')[1]))
    return np.array(q), np.array(p)

q, p = readGrid(FILENAME)

def gridValue(ar, er, incr, gr):
    if ar < amin or ar > amax:
        print("The requested a exceeds the grid boundary (39.4, 47.7) au. The output maybe inaccurate!")
    if er < 0 or er > emax:
        print("The request e exceeds the grid boundary (0, 0.25). The output maybe inaccurate!")
    if incr < 0 or incr > incmax:
        print("The request inc exceeds the grid boundary (0, 40) deg. The output maybe inaccurate!")
    gr = wrapOmega(gr)

    ai = np.argmin(np.abs(ar-alist))
    ei = np.argmin(np.abs(er-elist))
    inci = np.argmin(np.abs(incr-inclist))
    gi = np.argmin(np.abs(gr-glist))
    ag, eg, incg, gg = alist[ai], elist[ei], inclist[inci], glist[gi]

    # print(ai, ei, inci, gi)
    # print("The closest grid we find is (a, e, inc, omega): ")
    # print(ag, eg, incg, gg)

    index = gi + gnum * inci + (incnum * gnum) * ei  + (enum * incnum * gnum) * ai

    return q[index], p[index]


def If_da_esti(a, e, inc, Omega, omega):
    qforced, pforced = gridValue(a,e,inc,omega)
    q0, p0 = q_p_trans(inc, Omega)
    qfree, pfree = q0 - qforced, p0 - pforced
    If, Omegaf = I_Omega_trans(qfree, pfree)
    return If

a, e, inc, Omega, omega = (47.04647,0.21298,19.15152,127.1858,300.83752)

print("The free inclination for this TNO is: ")
print('{0:.4f} deg'.format(If_da_esti(a,e,inc, Omega, omega)))